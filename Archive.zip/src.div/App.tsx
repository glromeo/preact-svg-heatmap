import {createContext, h, VNode} from 'preact'
import {useMemo} from 'preact/hooks'
import {Heatmap} from './Heatmap'
import './App.css'
import {AppState} from './types'
import {createStore, useData, useSelector} from './hooks'

interface Props {
    color?: string;
}

const store = createStore({
    pointer: {
        x: 0,
        y: 0,
        z: 1
    }
}, (state, action) => {
    switch (action.type) {
        case "SET_POINTER":
            return {
                pointer: action.payload
            }
    }
    return state
})

export const AppContext = createContext(store)

function Header() {
    const pointer = useSelector<AppState, AppState['pointer']>(state => state.pointer)
    return <div className="Header">
        <div>
            <span>x:</span>
            <span>{pointer.x}</span>
        </div>
        <div>
            <span>y:</span>
            <span>{pointer.y}</span>
        </div>
        <div>
            <span>z:</span>
            <span>{pointer.z}</span>
        </div>
    </div>
}

export default function App(props: Props): VNode {

    const data = useData()

    const ranges = useMemo(() => {
        let minX = 1, maxX = 0
        for (const {x} of data) {
            if (x < minX) {
                minX = x
            } else if (x > maxX) {
                maxX = x
            }
        }
        let minY = 1, maxY = 0
        for (const {y} of data) {
            if (y < minY) {
                minY = y
            } else if (y > maxY) {
                maxY = y
            }
        }
        return {
            x: {
                min: minX,
                max: maxX,
                span: maxX - minX
            },
            y: {
                min: minY,
                max: maxY,
                span: maxY - minY
            }
        }
    }, [data])

    return (
        <AppContext.Provider value={store}>
            <div className="App">
                <Header />
                <div className="Body">
                    <Heatmap data={data} ranges={ranges}/>
                </div>
            </div>
        </AppContext.Provider>
    )
}
