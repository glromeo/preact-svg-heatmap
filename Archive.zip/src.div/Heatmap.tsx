import {h} from 'preact'
import {useCallback, useEffect, useLayoutEffect, useMemo, useState} from 'preact/hooks'
import {JSXInternal} from 'preact/src/jsx'

import {RectBox} from './hooks/heatmapGrid'
import {Data, Sample} from './types'
import {useDispatch} from './hooks'

import './Heatmap.css'

type Range = {
    min: number,
    max: number,
    span: number
}

export type HeatmapProps = {
    preview?: boolean,
    data: Data
    ranges: {
        x: Range,
        y: Range
    }
}


type Buckets = Record<number, Record<number, Sample[]>>

function addBucketValue(buckets: Buckets, column: number, row: number, sample: Sample) {
    let hzb = buckets[column]
    if (hzb === undefined) {
        buckets[column] = {
            [row]: [sample]
        }
    } else {
        let vtb = hzb[row]
        if (vtb === undefined) {
            hzb[row] = [sample]
        } else {
            hzb[row].push(sample)
        }
    }
}

type HeatmapSelection = {
    x: number;
    y: number;
    width: number;
    height: number;
    clientX: number;
    clientY: number;
    clientWidth: number;
    clientHeight: number;
    editing: boolean;
}

export type HeatmapModel = {
    data: Sample[]
    width: number
    height: number
    columns: number
    rows: number
}

const DEFAULT_MODEL = {
    data: [],
    width: 0,
    height: 0,
    columns: 0,
    rows: 0
}

const COLUMN_WIDTH = 75
const ROW_HEIGHT = 25

const NO_TRANSFORM = ['scale(1)', 'scalee(1)']

function useBuckets(model: HeatmapModel, view: RectBox) {
    return useMemo(() => {
        if (view) {
            const buckets: Buckets = {}
            const {x, y, width, height} = view
            const columnWidth = COLUMN_WIDTH * view.width / model.width
            const rowHeight = ROW_HEIGHT * view.height / model.height
            const minX = x
            const minY = y
            const maxX = x + width
            const maxY = y + height
            for (const sample of model.data) {
                const x = sample.x * model.width
                const y = sample.y * model.height
                if (x >= minX && x < maxX && y >= minY && y < maxY) {
                    const column = Math.floor((x - view.x) / columnWidth)
                    const row = Math.floor((y - view.y) / rowHeight)
                    addBucketValue(buckets, column, row, sample)
                }
            }
            return buckets
        } else {
            return null
        }
    }, [model, view])
}

function renderCells(model: HeatmapModel, buckets: Buckets, onTileClick: (column: number, row: number) => void) {
    if (!buckets) {
        return null
    }
    const {columns, rows} = model
    const overlay: JSXInternal.Element[] = []
    for (let column = 0; column < columns; column++) {
        const slice = buckets[column]
        const x = column * COLUMN_WIDTH
        if (slice) {
            for (let row = 0; row < rows; row++) {
                const bucket = slice[row]
                const y = row * ROW_HEIGHT
                if (bucket) {
                    const value = bucket.reduce((total, {z}) => total + z, 0) / bucket.length
                    overlay.push(
                        <div className="heatmap-cell" onClick={() => onTileClick(column, row)} style={{
                            backgroundColor: `hsl(200,80%,${Math.round(100 - 100 * value)}%)`,
                            left: x,
                            top: y,
                            width: COLUMN_WIDTH,
                            height: ROW_HEIGHT
                        }}>{bucket?.[0].name} ({bucket?.length})</div>
                    )
                } else {
                    overlay.push(
                        <div className="heatmap-cell" onClick={() => onTileClick(column, row)} style={{
                            backgroundColor: `hsl(200, 80%, 100%)`,
                            left: x,
                            top: y,
                            width: COLUMN_WIDTH,
                            height: ROW_HEIGHT
                        }}/>
                    )
                }
            }
        } else {
            for (let row = 0; row < rows; row++) {
                const y = row * ROW_HEIGHT
                overlay.push(
                    <div className="heatmap-cell" onClick={() => onTileClick(column, row)} style={{
                        backgroundColor: `hsl(200, 80%, 100%)`,
                        left: x,
                        top: y,
                        width: COLUMN_WIDTH,
                        height: ROW_HEIGHT
                    }}/>
                )
            }
        }
    }
    return overlay
}

const AXIS_WIDTH = 100
const AXIS_HEIGHT = 50

export function Heatmap({data, ranges: {x: rangeX, y: rangeY}}: HeatmapProps) {

    const dispatch = useDispatch()

    const [container, setContainer] = useState<HTMLDivElement>(null)
    const [model, setModel] = useState<HeatmapModel>(DEFAULT_MODEL)
    const [view, setView] = useState<RectBox>(null)
    const [zoom, setZoom] = useState<RectBox>(null)

    useLayoutEffect(() => {
        const createModel = (container: HTMLDivElement) => {
            let {width, height} = container.getBoundingClientRect()
            let columns = Math.floor((width-AXIS_WIDTH) / COLUMN_WIDTH)
            let rows = Math.floor((height-AXIS_HEIGHT) / ROW_HEIGHT)
            return {
                data,
                width: columns * COLUMN_WIDTH,
                height: rows * ROW_HEIGHT,
                columns,
                rows
            }
        }
        if (container) {
            const observer = new ResizeObserver(() => {
                const model = createModel(container)
                setModel(model)
                setView({x: 0, y: 0, width: model.width, height: model.height})
            })
            observer.observe(container)
            const model = createModel(container)
            setModel(model)
            setView({x: 0, y: 0, width: model.width, height: model.height})
            return () => {
                observer.disconnect()
            }
        }
    }, [container])


    const viewBuckets = useBuckets(model, view)
    const zoomBuckets = useBuckets(model, zoom)

    const onTileClick = useCallback((column: number, row: number) => {
        if (view) {
            const columnWidth = COLUMN_WIDTH * view.width / model.width
            const rowHeight = ROW_HEIGHT * view.height / model.height
            setZoom({
                x: view.x + column * columnWidth,
                y: view.y + row * rowHeight,
                width: columnWidth,
                height: rowHeight
            })
        } else {
            setZoom({
                x: column * COLUMN_WIDTH,
                y: row * ROW_HEIGHT,
                width: COLUMN_WIDTH,
                height: ROW_HEIGHT
            })
        }
    }, [model, view])

    const [cells, setCells] = useState(null)
    useEffect(() => {
        setCells(renderCells(model, viewBuckets, onTileClick))
    }, [model, view])
    const [overlay, setOverlay] = useState(null)
    useEffect(() => {
        setOverlay(renderCells(model, zoomBuckets, onTileClick))
    }, [model, zoom])

    const onMouseDown = useCallback(({clientX, clientY, shiftKey}) => {

    }, [])

    const onMouseMove = useCallback(({clientX, clientY}) => {
        dispatch({type: 'SET_POINTER', payload: {x: clientX, y: clientY, z: '?'}})
    }, [])

    const onMouseUp = useCallback(() => {

    }, [])

    const onWheel = useCallback(event => {
        if (!event.altKey) {
            let x, y, width, height
            if (view) {
                if (event.deltaY < 0) {
                    width = view.width >> 1
                    height = view.height >> 1
                } else {
                    width = view.width << 1
                    height = view.height << 1
                }
                x = Math.max(0, Math.min(model.width - width, view.x + event.clientX * view.width / model.width - width/2))
                y = Math.max(0, Math.min(model.height - height, view.y + event.clientY * view.height / model.height - height/2))
            } else {
                if (event.deltaY < 0) {
                    width = model.width >> 1
                    height = model.height >> 1
                } else {
                    width = model.width
                    height = model.height
                }
                x = Math.max(0, Math.min(model.width - width, event.clientX))
                y = Math.max(0, Math.min(model.height - height, event.clientY))
            }
            setZoom({x, y, width, height})
            event.stopPropagation()
            event.preventDefault()
        }
    }, [model, view])

    const [transform, setTransform] = useState(NO_TRANSFORM)
    const [transition, setTransition] = useState('none')

    useEffect(() => {
        if (zoom) {
            console.log('zoom:', zoom)
            const width = model.width
            const height = model.height
            const zx = width / zoom.width
            const zy = height / zoom.height
            const ox = zoom.x + zoom.width / 2
            const oy = zoom.y + zoom.height / 2
            const tx = zx !== 1 ? width / 2 - zx * ox : 0
            const ty = zy !== 1 ? height / 2 - zy * oy : 0
            setTransition('all ease-in-out 1s')
            setTransform([
                `matrix(${zx},0,0,${zy},${tx},${ty})`,
                `matrix(${1 / zx},0,0,${1 / zy},${zoom.x},${zoom.y})`
            ])
            // requestAnimationFrame(() => {
            //     setTransform([
            //         `translate(${-zoom.x}px,${-zoom.y}px) scale(${zoom}) translate(${zoom.x}px,${zoom.y}px)`,
            //         `translate(${zoom.x}px,${zoom.y}px) scale(${scale.x},${scale.y})`
            //     ])
            // })
        } else {
            setTransition('none')
            setTransform(NO_TRANSFORM)
        }

    }, [view, zoom])

    const onTransitionEnd = useCallback(() => {
        console.log("onTransitionEnd")
        setCells(overlay)
        setOverlay(null)
        setTransition('none')
        setTransform(NO_TRANSFORM)
        requestAnimationFrame(() => {
            setView(zoom)
            setZoom(null)
        })
    }, [cells, overlay, view, zoom])

    return (
        <div className="heatmap" ref={setContainer} style={{paddingTop: AXIS_HEIGHT, paddingLeft: AXIS_WIDTH}}>
            <div className="heatmap-pane" style={{width: model.width, height: model.height}}>
                <div className="heatmap-grid"
                     onTransitionEnd={onTransitionEnd}
                     onMouseDown={onMouseDown}
                     onMouseMove={onMouseMove}
                     onMouseUp={onMouseUp}
                     onWheel={onWheel}
                     style={{
                         transform: transform[0],
                         transition,
                         transformOrigin: 'top left'
                     }}>
                    {cells}
                    {overlay ? <div className="heatmap-overlay" style={{
                        transform: transform[1],
                        transformOrigin: 'top left'
                    }}>{overlay}</div> : null}
                </div>
            </div>
        </div>
    )
}
