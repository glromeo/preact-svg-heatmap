import {h} from 'preact'
import {useCallback, useLayoutEffect, useMemo, useRef, useState} from 'preact/hooks'
import {JSXInternal} from 'preact/src/jsx'

import './Heatmap.css'

import {Data, useGlobalState} from './App'

type RectBox = { x: number, y: number, width: number, height: number }

type ViewBox = RectBox & { text: string }

const INITIAL_VIEWBOX: ViewBox = {x: 0, y: 0, width: 1600, height: 900, text: '0 0 1600 900'}

type HeatmapDimensions = { width: number, height: number }

const COLUMN_WIDTH = 64
const ROW_HEIGHT = 24

const INITIAL_DIMENSIONS: HeatmapDimensions = {width: 0, height: 0}

const EMPTY_SELECTION: RectBox = {
  x: 0,
  y: 0,
  width: 0,
  height: 0
}

type HeatmapCell = {
  content: string
  value: number
  column: number
  row: number
  style: JSXInternal.CSSProperties
}

type AxisCell = {
  content: string
  style: JSXInternal.CSSProperties
}

function getContent(buckets: Record<number, Record<number, { name: string }[]>>, x: number, y: number) {
  let xBkt = buckets[x]
  if (!xBkt) {
    return ''
  }
  let yBkt = xBkt[y]
  if (!yBkt) {
    return ''
  }
  if (yBkt.length > 1) {
    return `multi (${yBkt.length})`
  } else {
    return yBkt[0].name || ''
  }
}

function getValue(buckets: Record<number, Record<number, { value: number }[]>>, x: number, y: number): number {
  let xBkt = buckets[x]
  if (!xBkt) {
    return 0
  }
  let yBkt = xBkt[y]
  if (!yBkt) {
    return 0
  }
  return yBkt.reduce((total, {value}) => total + value, 0) / yBkt.length
}

type Range = {
  min: number,
  max: number,
  span: number
}

export type HeatmapProps = {
  preview?: boolean,
  data: Data
  ranges: {
    x: Range,
    y: Range
  }
}

function sizeHeatmap(target: SVGSVGElement): HeatmapDimensions {
  const {width, height} = target.getBoundingClientRect()
  return {
    width,
    height
  }
}

export function Heatmap({data}: HeatmapProps) {

  const [state, setState] = useGlobalState()

  const [{
    width,
    height
  }, setDimensions] = useState(INITIAL_DIMENSIONS)

  const [
    columns, rows
  ] = useMemo(() => [Math.floor(width / COLUMN_WIDTH), Math.floor(height / ROW_HEIGHT)], [width, height])

  const ref = useRef<SVGSVGElement>(null)

  useLayoutEffect(() => {
    const target = ref.current
    if (target) {
      const observer = new ResizeObserver(() => {
        setDimensions(sizeHeatmap(target))
      })
      observer.observe(target)
      setDimensions(sizeHeatmap(target))
    }
  }, [ref])

  const [zoom, setZoom] = useState(1)
  const [viewBox, setViewBox] = useState(INITIAL_VIEWBOX)

  const [cells, xAxis, yAxis] = useMemo(() => {
    const buckets: Record<number, Record<number, { name: string, value: number }[]>> = {}
    for (const sample of data) {
      const name = sample.name
      const x = sample.x * INITIAL_VIEWBOX.width
      const y = sample.y * INITIAL_VIEWBOX.height
      const z = sample.z * 100
      let gridColumn = Math.floor(x / COLUMN_WIDTH)
      let gridRow = Math.floor(y / ROW_HEIGHT)
      let columnBkt = buckets[gridColumn]
      if (columnBkt === undefined) {
        buckets[gridColumn] = {
          [gridRow]: [{name, value: z}]
        }
      } else {
        let rowBk = columnBkt[gridRow]
        if (rowBk === undefined) {
          columnBkt[gridRow] = [{name, value: z}]
        } else {
          columnBkt[gridRow].push({name, value: z})
        }
      }
    }
    const cells: JSXInternal.Element[] = []
    for (let row = 0; row < rows; row++) {
      for (let column = 0; column < columns; column++) {
        let value = getValue(buckets, column, row)
        // content: getContent(buckets, gridColumn, gridRow),
        cells.push(<rect
          fill={`hsl(200,80%,${100 - Math.round(value)}%)`}
          x={column * COLUMN_WIDTH}
          y={row * ROW_HEIGHT}
          width={COLUMN_WIDTH}
          height={ROW_HEIGHT}
        />)
      }
    }
    const xAxis: AxisCell[] = []
    // for (let gridColumn = 0; gridColumn < columnCount; gridColumn++) {
    //     xAxis.push({
    //         content: `${(rangeX.min + rangeX.span * gridColumn / columnCount).toFixed(2)}`,
    //         style: {
    //             gridColumn: 2 + gridColumn,
    //             gridRow: 1
    //         }
    //     })
    // }
    const yAxis: AxisCell[] = []
    // for (let gridRow = 0; gridRow < rowCount; gridRow++) {
    //     yAxis.push({
    //         content: `${(rangeY.min + rangeY.span * gridRow / rowCount).toFixed(2)}`,
    //         style: {
    //             gridColumn: 1,
    //             gridRow: 2 + gridRow
    //         }
    //     })
    // }
    return [cells, xAxis, yAxis]
  }, [viewBox, columns, rows, data])

  const [selection, setSelection] = useState<RectBox | null>(null)
  const [selecting, setSelecting] = useState(false)

  const tx=zoom > 1 ? (1-zoom) * state.pointer.x : (1-zoom) * width / 2;
  const ty=zoom > 1 ? (1-zoom) * state.pointer.y : (1-zoom) * height / 2;

  return (
    <svg className="heatmap" ref={ref} width="100%" height="100%" preserveAspectRatio="none"
         onMouseDown={useCallback(({currentTarget, clientX, clientY}) => {
           const svg = ref.current!
           const domPoint = new DOMPointReadOnly(clientX, clientY)
           const pt = domPoint.matrixTransform(svg.getScreenCTM().inverse())
           setSelection({
             x: pt.x,
             y: pt.y,
             width: 1,
             height: 1
           })
           setSelecting(true)
         }, [selection])}
         onMouseMove={useCallback(({clientX, clientY}) => {
           const svg = ref.current!
           const domPoint = new DOMPointReadOnly(clientX, clientY)
           const pt = domPoint.matrixTransform(svg.getScreenCTM().inverse())
           if (selecting) {
             setSelection({
               ...selection,
               width: Math.max(1, pt.x - selection.x),
               height: Math.max(1, pt.y - selection.y)
             })
           }
           setState({...state, pointer: {...state.pointer, x: pt.x, y: pt.y}})
         }, [state, selection])}
         onMouseUp={useCallback(() => {
           setSelecting(false)
         }, [selection])}
         onWheel={useCallback(event => {
           if (!event.altKey) {
             if (event.deltaY > 0) {
               setZoom(zoom - 0.1)
             } else {
               setZoom(zoom + 0.1)
             }
             setState({...state, pointer: {...state.pointer, z: zoom}})
             event.stopPropagation()
             event.preventDefault()
           }
         }, [state, zoom, width, height])}>
      <g transform={`translate(${tx}, ${ty}) scale(${zoom})`}>
        {cells}
      </g>
      {selection ? <rect className="selection" {...selection}/> : null}
    </svg>
  )
}
