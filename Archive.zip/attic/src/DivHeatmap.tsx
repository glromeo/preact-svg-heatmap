import {h} from 'preact'
import {useCallback, useLayoutEffect, useMemo, useRef, useState} from 'preact/hooks'
import {JSXInternal} from 'preact/src/jsx'

import './DivHeatmap.css'
import {Data} from './App'

const INITIAL_DIMENSIONS = {x: 0, y: 0, width: 0, height: 0}

type HeatmapCell = {
    content: string
    value: number
    column: number
    row: number
    style: JSXInternal.CSSProperties
}

type AxisCell = {
    content: string
    style: JSXInternal.CSSProperties
}

function getContent(buckets: Record<number, Record<number, { name: string }[]>>, x: number, y: number) {
    let xBkt = buckets[x]
    if (!xBkt) {
        return ''
    }
    let yBkt = xBkt[y]
    if (!yBkt) {
        return ''
    }
    if (yBkt.length > 1) {
        return `multi (${yBkt.length})`
    } else {
        return yBkt[0].name || ''
    }
}

function getValue(buckets: Record<number, Record<number, { value: number }[]>>, x: number, y: number): number {
    let xBkt = buckets[x]
    if (!xBkt) {
        return 0
    }
    let yBkt = xBkt[y]
    if (!yBkt) {
        return 0
    }
    return yBkt.reduce((total, {value}) => total + value, 0) / yBkt.length
}

type Range = {
    min: number,
    max: number,
    span: number
}

export type HeatmapProps = {
    preview?: boolean,
    data: Data
    ranges: {
        x: Range,
        y: Range
    }
}

let previewElement: HTMLDivElement

export function DivHeatmap({preview = false, data, ranges}: HeatmapProps) {

    const [zoom, setZoom] = useState(1)

    const [{
        x: x0,
        y: y0,
        width,
        height
    }, setDimensions] = useState<{ x: number, y: number, width: number, height: number }>(INITIAL_DIMENSIONS)

    const ref = useRef<HTMLDivElement>(null)

    useLayoutEffect(() => {
        const target = ref.current
        if (target) {
            const observer = new ResizeObserver(() => {
                setDimensions(target.getBoundingClientRect())
            })
            observer.observe(target)
            setDimensions(target.getBoundingClientRect())
        }
    }, [ref])

    const [columnCount, gridTemplateColumns] = useMemo(() => {
        const columns = []
        for (let x = 0; x < 10 * zoom; x++) {
            columns.push(zoom + 'fr')
        }
        return [columns.length, '50px ' + columns.join(' ')]
    }, [width, zoom])

    const [rowCount, gridTemplateRows] = useMemo(() => {
        const rows = []
        for (let y = 0; y < 10 * zoom; y++) {
            rows.push(zoom + 'fr')
        }
        return [rows.length, '25px ' + rows.join(' ')]
    }, [height, zoom])

    const [cells, xAxis, yAxis] = useMemo(() => {
        const buckets: Record<number, Record<number, { name: string, value: number }[]>> = {}
        const rangeX = ranges.x
        const rangeY = ranges.y
        for (const {name, x, y, z} of data) {
            let gridColumn = 1 + Math.floor((x - rangeX.min) / rangeX.span * columnCount)
            let gridRow = 1 + Math.floor((y - rangeY.min) / rangeY.span * rowCount)
            let columnBkt = buckets[gridColumn]
            if (columnBkt === undefined) {
                buckets[gridColumn] = {
                    [gridRow]: [{name, value: z}]
                }
            } else {
                let rowBk = columnBkt[gridRow]
                if (rowBk === undefined) {
                    columnBkt[gridRow] = [{name, value: z}]
                } else {
                    columnBkt[gridRow].push({name, value: z})
                }
            }
        }
        const cells: HeatmapCell[] = []
        for (let gridRow = 1; gridRow <= rowCount; gridRow++) {
            for (let gridColumn = 1; gridColumn <= columnCount; gridColumn++) {
                let value = getValue(buckets, gridColumn, gridRow)
                cells.push({
                    content: getContent(buckets, gridColumn, gridRow),
                    value,
                    column: gridColumn - 1,
                    row: gridRow - 1,
                    style: {
                        backgroundColor: `hsl(200,80%,${100 - value * 100}%)`,
                        gridColumn: 1 + gridColumn,
                        gridRow: 1 + gridRow
                    }
                })
            }
        }
        const xAxis: AxisCell[] = []
        for (let gridColumn = 0; gridColumn < columnCount; gridColumn++) {
            xAxis.push({
                content: `${(rangeX.min + rangeX.span * gridColumn / columnCount).toFixed(2)}`,
                style: {
                    gridColumn: 2 + gridColumn,
                    gridRow: 1
                }
            })
        }
        const yAxis: AxisCell[] = []
        for (let gridRow = 0; gridRow < rowCount; gridRow++) {
            yAxis.push({
                content: `${(rangeY.min + rangeY.span * gridRow / rowCount).toFixed(2)}`,
                style: {
                    gridColumn: 1,
                    gridRow: 2 + gridRow
                }
            })
        }
        return [cells, xAxis, yAxis]
    }, [gridTemplateColumns, gridTemplateRows, data])

    return (
        <div className="heatmap" ref={ref} onWheel={useCallback(event => {
            if (event.altKey) {
                let current = ref.current as HTMLDivElement
                let z = event.deltaY > 0 ? Math.max(1, zoom - 1) : Math.min(10, zoom + 1)
                setZoom(z)
                // const {
                //     offsetLeft: ol0,
                //     offsetWidth: ow0,
                //     offsetTop: ot0,
                //     offsetHeight: oh0
                // } = (event.target as HTMLDivElement);
                // const {x:x1, y:y1} = (event.target as HTMLDivElement).getBoundingClientRect();
                // let cx = 4*(x1-x0-50)/width
                // let cy = 4*(y1-y0-25)/height
                // console.log("cx",cx,"cy",cy)
                // requestAnimationFrame(() => {
                //     const {offsetLeft:ol1, offsetWidth:ow1, offsetTop:ot1, offsetHeight:oh1} = (event.target as HTMLDivElement)
                //     current.scrollLeft += (ol1 - ol0) + (ow1-ow0)/2*cx
                //     current.scrollTop += (ot1 - ot0) + (oh1-oh0)/2*cy
                // })
                event.stopPropagation()
                event.preventDefault()
            }
        }, [zoom, width, height, x0, y0])}>
            <div className="heatmap-grid"
                 style={{
                     width: zoom * width,
                     height: zoom * height,
                     gridTemplateColumns,
                     gridTemplateRows
                 }}>
                <div className="zoom-cell">{zoom}</div>
                {xAxis.map((cell, index) => (
                    <div key={index} className="x-axis-cell" style={cell.style}>{cell.content}</div>
                ))}
                {yAxis.map((cell, index) => (
                    <div key={index} className="y-axis-cell" style={cell.style}>{cell.content}</div>
                ))}
                {cells.map((cell, index) => (
                    <div key={index} data-index={index} className="heatmap-cell" style={cell.style}>{cell.content}</div>
                ))}
            </div>
        </div>
    )
}
