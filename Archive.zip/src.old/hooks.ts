import {useMemo} from 'preact/hooks'
import {Data} from './types'

function normalDistributionRandom() {
    let num = -1;
    while (num > 1 || num < 0) {
        let u = 0, v = 0;
        while (u === 0) u = Math.random();
        while (v === 0) v = Math.random();
        num = Math.sqrt(-5.0 * Math.log(u)) * Math.cos(5.0 * Math.PI * v) / 10.0 + 0.5;
    }
    return num
}

export const useData = () => useMemo<Data>(() => {
    const POINTS = 1000
    const data = new Array(POINTS)
    let d = 0
    for (let p = 0; p < POINTS; p++) {
        data[d++] = {
            name: `p:${p}`,
            x: normalDistributionRandom(), // Math.random(),
            y: normalDistributionRandom(), // Math.random(),
            z: Math.random()
        }
    }
    return data.sort(({x: lx, y: ly}, {x: rx, y: ry}) => lx - rx || ly - ry)
}, [])