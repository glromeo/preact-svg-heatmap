import {h} from 'preact'
import {useCallback, useLayoutEffect, useMemo, useRef, useState} from 'preact/hooks'
import {JSXInternal} from 'preact/src/jsx'

import {RectBox} from './hooks/heatmapGrid'
import {Data, Sample} from './types'
import {useDispatch} from './hooks'

import './Heatmap.css'
import {AXIS_HEIGHT, AXIS_WIDTH, Ticks, XAxis, YAxis} from './HeatmapAxes'

type Range = {
  min: number,
  max: number,
  span: number
}

export type HeatmapProps = {
  preview?: boolean,
  data: Data
  ranges: {
    x: Range,
    y: Range
  }
}


type Buckets = Record<number, Record<number, Sample[]>>

type HeatmapSelection = {
  x: number;
  y: number;
  width: number;
  height: number;
  clientX: number;
  clientY: number;
  clientWidth: number;
  clientHeight: number;
  editing: boolean;
}

export type HeatmapModel = {
  data: Sample[]
  width: number
  height: number
  columns: number
  rows: number
}

const DEFAULT_MODEL = {
  data: [],
  width: 0,
  height: 0,
  columns: 0,
  rows: 0
}

export const COLUMN_WIDTH = 90
export const ROW_HEIGHT = 30

const COLLAPSED_BOX: RectBox = {x: 0, y: 0, width: 0, height: 0}

function useBuckets(heatmap: HeatmapModel, view: RectBox) {
  return useMemo(() => {
    if (view) {
      const buckets: Buckets = {}
      const {height, width, data} = heatmap
      const columnWidth = COLUMN_WIDTH * view.width / width
      const rowHeight = ROW_HEIGHT * view.height / height
      const minX = view.x
      const minY = view.y
      const maxX = view.x + view.width
      const maxY = view.y + view.height
      for (const sample of data) {
        const x = sample.x * width
        const y = sample.y * height
        if (x >= minX && x < maxX && y >= minY && y < maxY) {
          const bucketX = x - x % columnWidth
          const bucketY = y - y % rowHeight
          let slice = buckets[bucketX]
          if (slice === undefined) {
            buckets[bucketX] = {[bucketY]: [sample]}
          } else {
            const bucket = slice[bucketY]
            if (bucket === undefined) {
              slice[bucketY] = [sample]
            } else {
              slice[bucketY].push(sample)
            }
          }
        }
      }
      return buckets
    } else {
      return null
    }
  }, [heatmap, view])
}

export function Heatmap({data, ranges}: HeatmapProps) {

  const dispatch = useDispatch()

  const [container, setContainer] = useState<HTMLDivElement>(null)
  const [heatmap, setHeatmap] = useState<HeatmapModel>(DEFAULT_MODEL)
  const [view, setView] = useState<RectBox>(COLLAPSED_BOX)
  const [zoom, setZoom] = useState<RectBox>(null)
  const [drag, setDrag] = useState<{ x: number, y: number, offsetX: number, offsetY: number }>(null)

  useLayoutEffect(() => {
    const createModel = (container: HTMLDivElement) => {
      let {width, height} = container.getBoundingClientRect()
      let columns = Math.floor((width - AXIS_WIDTH) / COLUMN_WIDTH)
      let rows = Math.floor((height - AXIS_HEIGHT) / ROW_HEIGHT)
      return {
        data,
        width: columns * COLUMN_WIDTH,
        height: rows * ROW_HEIGHT,
        columns,
        rows
      }
    }
    if (container) {
      const observer = new ResizeObserver(() => {
        const heatmap = createModel(container)
        setHeatmap(heatmap)
        setView({x: 0, y: 0, width: heatmap.width, height: heatmap.height})
      })
      observer.observe(container)
      const heatmap = createModel(container)
      setHeatmap(heatmap)
      setView({x: 0, y: 0, width: heatmap.width, height: heatmap.height})
      return () => {
        observer.disconnect()
      }
    }
  }, [container])


  const viewBuckets = useBuckets(heatmap, view)
  const zoomBuckets = useBuckets(heatmap, null)

  const onTileClick = useCallback((column: number, row: number) => {
    const columnWidth = COLUMN_WIDTH * view.width / heatmap.width
    const rowHeight = ROW_HEIGHT * view.height / heatmap.height
    setZoom({
      x: view.x + column * columnWidth,
      y: view.y + row * rowHeight,
      width: columnWidth,
      height: rowHeight
    })
  }, [heatmap, view])

  const animationFrame = useRef(null)

  const ticks = useMemo<Ticks>(() => {
    const scaleX = 100 * ranges.x.span / heatmap.columns
    const baseX = 100 * ranges.x.min
    const x: string[] = []
    for (let column = 1; column < heatmap.columns; column++) {
      x.push(String(Math.round(baseX + scaleX * column)))
    }
    const scaleY = 100 * ranges.y.span / heatmap.rows
    const baseY = 100 * ranges.y.min
    const y: string[] = []
    for (let row = 1; row < heatmap.rows; row++) {
      y.push(String(Math.round(baseY + scaleY * row)))
    }
    const fX = scaleX / COLUMN_WIDTH
    const fY = scaleY / ROW_HEIGHT
    return {
      x,
      y,
      xLabel: (x: number) => (baseX + fX * x).toFixed(2),
      yLabel: (y: number) => (baseY + fY * y).toFixed(2)
    }
  }, [heatmap.columns, heatmap.rows, ranges])

  // console.log(view)

  const toPoint = useCallback(({offsetX, offsetY}: { offsetX: number, offsetY: number }) => {
    return {
      x: offsetX * view.width / heatmap.width + view.x,
      y: offsetY * view.height / heatmap.height + view.y
    }
  }, [view])

  return (
    <div className="heatmap" ref={setContainer}>
      <XAxis range={heatmap.width} left={view.x} width={view.width} ticks={ticks}/>
      <YAxis range={heatmap.height} top={view.y} height={view.height} ticks={ticks}/>
      <svg className="heatmap-grid" style={{left: AXIS_WIDTH, top: AXIS_HEIGHT}}
           width={heatmap.width}
           height={heatmap.height}
           onDblClick={useCallback(() => {
             setView({x: 0, y: 0, width: heatmap.width, height: heatmap.height})
           }, [heatmap])}
           onMouseDown={event => setDrag({
             offsetX: event.offsetX,
             offsetY: event.offsetY,
             x: view.x,
             y: view.y}
           )}
           onMouseMove={useCallback(event => {
             cancelAnimationFrame(animationFrame.current)
             animationFrame.current = requestAnimationFrame(() => {
               const {x, y} = toPoint(event)
               if (drag) {
                 let dx = (event.offsetX - drag.offsetX)* view.width / heatmap.width
                 let dy = (event.offsetY - drag.offsetY)* view.height / heatmap.height
                 console.log(dx, dy, x, y)
                 setView({...view, x: drag.x + dx, y: drag.y + dy})
               }
               dispatch({type: 'SET_POINTER', payload: {x, y, z: '?'}})
             })
             event.preventDefault()
             event.stopPropagation()
           }, [drag, view])}
           onMouseUp={useCallback(event => {
             const {offsetX, offsetY} = event
             const x = offsetX + view.x
             const y = offsetY + view.y
             setDrag(null)
           }, [])}
           onMouseLeave={useCallback(() => {
             setDrag(null)
           }, [])}
           onWheel={useCallback(({deltaY, offsetX, offsetY}) => {
             // delta > 0 zoom in -> view shrinks
             let width: number
             let height: number
             if (view) {
               width = view.width - deltaY
               height = view.height - deltaY
             } else {
               width = heatmap.width - deltaY
               height = heatmap.height - deltaY
             }
             let x: number
             let y: number
             if (deltaY < 0) {
               x = view.x
               y = view.y
             } else {
               x = view.x + deltaY / 2
               y = view.y + deltaY / 2
             }
             x = Math.min(heatmap.width, Math.max(0, x))
             y = Math.min(heatmap.height, Math.max(0, y))
             width = Math.min(heatmap.width, Math.max(0, width))
             height = Math.min(heatmap.height, Math.max(0, height))
             setView({x, y, width, height})
           }, [heatmap, view])}>
        <g className="grid">
          {useMemo(() => {
            const zx = heatmap.width / view.width
            const zy = heatmap.height / view.height
            const columnWidth = COLUMN_WIDTH // * view.width / heatmap.width
            const rowHeight = ROW_HEIGHT // * view.height / heatmap.height
            const grid: JSXInternal.Element[] = []
            let sliceEntries: [string, Sample[]][]
            for (let [keyX, slice] of Object.entries(viewBuckets)) {
              const x = Number(keyX) * zx
              sliceEntries = Object.entries(slice)
              for (let [keyY, bucket] of sliceEntries) {
                const value = bucket ? bucket.reduce((total, {z}) => total + z, 0) / bucket.length : 0
                const y = Number(keyY) * zy
                const hasBadge = false // value && bucket.length > 1
                grid.push(
                  <g key={keyX + keyY}>
                    <rect fill={`hsl(200,80%,${Math.round(100 - 100 * value)}%)`} x={x} y={y}
                          width={columnWidth} height={rowHeight}/>
                    {hasBadge && (
                      <g>
                        <circle className="badge-background" cx={12} cy={12}
                                r={bucket.length > 99 ? 12 : 8}/>
                        <text className="badge-number" x={12} y={15}
                              text-anchor="middle">{bucket.length}</text>
                      </g>
                    )}
                  </g>
                )
              }
            }
            grid.push(<line key="left-line" x1={0} y1={0} x2={0} y2={view.height}/>)
            for (let x = 0; x < view.width; x += columnWidth) {
              grid.push(<line key={`line-v-${x}`} x1={x} y1={0} x2={x} y2={view.height}/>)
            }
            grid.push(<line key="right-line" x1={view.width} y1={0} x2={view.width} y2={view.height}/>)

            grid.push(<line key={'top-line'} x1={0} y1={0} x2={view.width} y2={0}/>)
            for (let y = 0; y < view.height; y += rowHeight) {
              grid.push(<line key={`line-h-${y}`} x1={0} y1={y} x2={view.width} y2={y}/>)
            }
            grid.push(<line key={'bottom-line'} x1={0} y1={view.height} x2={view.width} y2={view.height}/>)

            return grid
          }, [heatmap, view, viewBuckets])}
        </g>
        <g className="zoom">

        </g>
      </svg>
    </div>
  )
}
