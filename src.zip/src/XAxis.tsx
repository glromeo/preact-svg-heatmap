import {h} from 'preact'
import {useDispatch} from './hooks'
import {useRef, useState} from 'preact/hooks'
import {AXIS_HEIGHT, AXIS_WIDTH, COLUMN_WIDTH} from './constants'
import {XCursor} from './XCursor'

const trxBaseVal = (svg: SVGSVGElement) => (svg.firstElementChild as SVGGElement).transform.baseVal

export function XAxis(props: { width: number, origin: number, scale: number, tick: (x: number) => string, onChange: (origin: number | undefined, scale: number | undefined) => void }) {
    const {width, origin, scale, tick, onChange} = props
    const dispatch = useDispatch()

    const y2 = AXIS_HEIGHT - 10
    const y1 = 2 * y2 / 3
    const dy = y1 - 2

    const columnWidth = COLUMN_WIDTH / Math.floor(scale)
    let minX = Math.max(0, Math.min(width - width / scale, -origin))
    minX -= minX % columnWidth
    const maxX = width

    const ticks = []
    for (let x = minX; x < maxX; x += columnWidth) {
        ticks.push(
            <g key={x} transform={`translate(${x},0)`}>
                <text className="x-tick" dy={dy}>{tick(x / width)}</text>
                <line y1={y1} y2={y2}/>
            </g>
        )
    }

    const [svg, setSvg] = useState<SVGSVGElement>(null)

    const animationFrame = useRef(0)
    const [mouseDownX, setMouseDownX] = useState<number>(null)

    const shrink = 1 / scale

    const toPoint = (offsetX: number) => origin + offsetX / scale

    return (
        <svg ref={setSvg} style={{left: AXIS_WIDTH}} width={width} height={AXIS_HEIGHT}
             onMouseDown={event => {
                 trxBaseVal(svg).appendItem(svg.createSVGTransform())
                 setMouseDownX(toPoint(event.offsetX))
             }}
             onMouseMove={event => {
                 cancelAnimationFrame(animationFrame.current)
                 animationFrame.current = requestAnimationFrame(() => {
                     let x = toPoint(event.offsetX)
                     if (mouseDownX) {
                         let dx = x - mouseDownX
                         x -= dx
                         trxBaseVal(svg).getItem(2).setTranslate(dx, 0)
                     }
                     dispatch({
                         type: 'SET_POINTER',
                         payload: {
                             x: x - origin,
                             y: 0,
                             z: '-'
                         }
                     })
                 })
             }}
             onMouseUp={event => {
                 if (mouseDownX) {
                     trxBaseVal(svg).removeItem(2)
                     const dx = toPoint(event.offsetX) - mouseDownX
                     onChange(origin + dx * scale, undefined)
                     setMouseDownX(null)
                 }
             }}
             onWheel={event => {
                 let update: number
                 if (event.deltaY < 0) {
                     update = scale * 1.125
                 } else {
                     update = Math.max(1, scale / 1.125)
                 }
                 let offsetX = event.offsetX * scale / update
                 offsetX -= offsetX % columnWidth + columnWidth / 2
                 let x = toPoint(offsetX)
                 onChange(origin * update / scale + (x - x * update / scale), update)
             }}>
            <g className="axis" transform={`scale(${scale}, 1) translate(${origin},0)`}>
                <line key="left" x1={shrink} y1={y2 / 2} x2={shrink} y2={y2}/>
                <line key="bottom" x1={0} y1={y2} x2={width} y2={y2}/>
                <line key="right" x1={width - shrink} y1={y2 / 2} x2={width - shrink} y2={y2}/>
                {ticks}
                <XCursor key="cursor" width={width} origin={origin} label={tick}/>
            </g>
            {/*<rect fill={`rgba(250, 225, 50, 0.25)`} x={origin} y={20} width={view} height={AXIS_HEIGHT - 30}/>*/}
            <style>{`
                line { vector-effect: non-scaling-stroke; }
                .x-tick { transform: scale(${shrink}, 1); }
            `}</style>
        </svg>
    )
}
