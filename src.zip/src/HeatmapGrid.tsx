import {JSXInternal} from 'preact/src/jsx'
import {useDispatch} from './hooks'
import {useCallback, useMemo, useRef, useState} from 'preact/hooks'
import {AXIS_HEIGHT, AXIS_WIDTH, COLUMN_WIDTH, ROW_HEIGHT} from './constants'
import {h} from 'preact'
import {HeatmapView} from './Heatmap'

export type HeatmapGridProps = {
    width: number
    height: number
    view: HeatmapView
    tiles: JSXInternal.Element[]
    onViewChange: (view: HeatmapView) => void
}

export function HeatmapGrid({width, height, view, tiles, onViewChange}: HeatmapGridProps): JSXInternal.Element {
    const dispatch = useDispatch()
    const animationFrame = useRef(0)
    const gRef = useRef<SVGGElement>()
    const [drag, setDrag] = useState<{ x: number, y: number, offsetX: number, offsetY: number }>(null)

    const left = view.x
    const top = view.y
    const scale = view.scale

    const transform = `translate(${-left * scale},${-top * scale})` // scale(${1/zx},${1/zy})`

    return (
        <svg className="heatmap-grid" style={{left: AXIS_WIDTH, top: AXIS_HEIGHT}}
             width={width}
             height={height}
             onDblClick={event => {
                 const target = event.target as SVGRectElement
                 let x = target.x.baseVal.value
                 let y = target.y.baseVal.value
                 let scale = Math.min(width / COLUMN_WIDTH, height / ROW_HEIGHT)
                 const hvw = width / scale
                 const hvh = height / scale
                 x = Math.max(0, Math.min(width - hvw, x))
                 y = Math.max(0, Math.min(height - hvh, y))
                 onViewChange({x, y, scale})
             }}
             onMouseDown={event => {
                 const g = gRef.current!
                 const svg = g.parentElement as unknown as SVGSVGElement
                 g.transform.baseVal.appendItem(svg.createSVGTransform())
                 setDrag({
                         offsetX: event.offsetX,
                         offsetY: event.offsetY,
                         x: left,
                         y: top
                     }
                 )
             }}
             onMouseMove={event => {
                 const g = gRef.current!
                 cancelAnimationFrame(animationFrame.current)
                 animationFrame.current = requestAnimationFrame(() => {
                     let {offsetX, offsetY} = event
                     if (drag) {
                         const svg = g.parentElement as unknown as SVGSVGElement
                         let dx = event.offsetX - drag.offsetX
                         let dy = event.offsetY - drag.offsetY
                         g.transform.baseVal.getItem(1).setTranslate(dx, dy)
                     }
                     const {x, y} = {
                         x: left + offsetX / scale,
                         y: top + offsetY / scale
                     }
                     dispatch({type: 'SET_POINTER', payload: {x, y, z: '-'}})
                 })
                 event.preventDefault()
                 event.stopPropagation()
             }}
             onMouseUp={event => {
                 if (drag) {
                     gRef.current!.transform.baseVal.removeItem(1)
                     let dx = (event.offsetX - drag.offsetX) / scale
                     let dy = (event.offsetY - drag.offsetY) / scale
                     let x = Math.max(0, Math.min(width - width / scale, drag.x - dx))
                     let y = Math.max(0, Math.min(height - height / scale, drag.y - dy))
                     onViewChange({x, y, scale})
                     setDrag(null)
                 }
             }}
             onMouseLeave={useCallback(() => {
                 setDrag(null)
             }, [])}
             onWheel={event => {
                 let {offsetX: x, offsetY: y} = event
                 let scale: number
                 if (event.deltaY < 0) {
                     scale = view.scale * 1.1
                     x = left + (1.1 * x - width / 2) / scale
                     y = top + (1.1 * y - height / 2) / scale
                 } else {
                     scale = view.scale / 1.1
                     x = left - width / view.scale * 0.125
                     y = top - height / view.scale * 0.125
                 }
                 const hvw = width / scale
                 const hvh = height / scale
                 x = Math.max(0, Math.min(width - hvw, x))
                 y = Math.max(0, Math.min(height - hvh, y))
                 onViewChange({x, y, scale})
             }}>
            <g className="grid animated" ref={gRef}
               onTransitionEnd={event => {
                   console.log('transition end')
               }}
               transform={transform}>
                <g>{tiles}</g>
                <g>{useMemo(() => {
                    const lines: JSXInternal.Element[] = []
                    const columnWidth = COLUMN_WIDTH
                    const rowHeight = ROW_HEIGHT
                    let x1 = Math.max(0, left)
                    let y1 = Math.max(0, top)
                    const minX = x1 - (x1 % columnWidth)
                    const minY = y1 - (y1 % rowHeight)
                    const maxScale = Math.max(1, scale)
                    const maxX = width * maxScale
                    const maxY = height * maxScale
                    for (let x = minX; x <= maxX; x += columnWidth) {
                        lines.push(<line key={`meridian-${x}`} x1={x} y1={minY} x2={x} y2={maxY}/>)
                    }
                    for (let y = minY; y <= maxY; y += rowHeight) {
                        lines.push(<line key={`parallel-${y}`} x1={minX} y1={y} x2={maxX} y2={y}/>)
                    }
                    return lines
                }, [width, height, view])}</g>
            </g>
        </svg>
    )
}