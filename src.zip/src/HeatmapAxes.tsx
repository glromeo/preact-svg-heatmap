import {h} from 'preact'
import {useSelector} from './hooks'
import {AppState} from './types'
import {COLUMN_WIDTH, ROW_HEIGHT} from './Heatmap'

export const AXIS_WIDTH = 60
export const AXIS_HEIGHT = 40
const AXIS_STYLE = {left: {left: AXIS_WIDTH}, top: {top: AXIS_HEIGHT}}
export type Ticks = {
    x: string[]
    y: string[]
    xLabel: (x: number) => string
    yLabel: (x: number) => string
}

function XCursor({label}: { label: (x: number) => string }) {
    const pointerX = useSelector<AppState, number>(state => state.pointer.x)
    const y2 = AXIS_HEIGHT - 10
    const y1 = 2 * y2 / 3
    return (
        <g className="axis pointer" transform={`translate(${pointerX},0)`}>
            <text dy={y1 - 2}>{label(pointerX)}</text>
            <line y1={y1} y2={y2}/>
        </g>
    )
}

export function XAxis(props: { width: number, left: number, scale: number, ticks: Ticks }) {
    const {width, left, scale, ticks} = props
    const y2 = AXIS_HEIGHT - 10
    const y1 = 2 * y2 / 3
    const dy = y1 - 2
    const view = width / scale
    const tx = left < 0 || left > width - view ? -left : 0
    return (
        <svg style={AXIS_STYLE.left} width={width} height={AXIS_HEIGHT}>
            <g className="axis" transform={`translate(${tx},0)`}>
                <line key="axis-left" x1={1} y1={y2 / 2} x2={1} y2={y2}/>
                <line key="axis-bottom" x1={0} y1={y2} x2={width} y2={y2}/>
                <line key="axis-right" x1={width - 1} y1={y2 / 2} x2={width - 1} y2={y2}/>
                {ticks.x.map((tick, index) => (
                    <g key={index} transform={`translate(${COLUMN_WIDTH + index * COLUMN_WIDTH},0)`}>
                        <text dy={dy}>{tick}</text>
                        <line y1={y1} y2={y2}/>
                    </g>
                ))}
                <XCursor key="cursor" label={ticks.xLabel}/>
            </g>
            <rect fill={`rgba(250, 225, 50, 0.25)`} x={left} y={20} width={view} height={AXIS_HEIGHT - 30}/>
        </svg>
    )
}

function YCursor({label}: { label: (x: number) => string }) {
    const pointerY = useSelector<AppState, number>(state => state.pointer.y)
    const x2 = AXIS_WIDTH - 10
    const x1 = 3 * x2 / 4
    return (
        <g className="axis pointer" transform={`translate(0,${pointerY})`}>
            <text dx={x1 - 16} dy=".33em">{label(pointerY)}</text>
            <line x1={x1} x2={x2}/>
        </g>
    )
}

export function YAxis(props: { height: number, top: number, scale: number, ticks: Ticks }) {
    const {height, top, scale, ticks} = props
    const x2 = AXIS_WIDTH - 10
    const x1 = 3 * x2 / 4
    const dx = x1 - 10
    const view = height / scale
    const ty = top < 0 || top > height - view ? -top : 0
    return (
        <svg style={AXIS_STYLE.top} width={AXIS_WIDTH} height={height}>
            <g className="axis" transform={`translate(0,${ty})`}>
                <line x1={x2 / 2} y1={1} x2={x2} y2={1}/>
                <line x1={x2} y1={0} x2={x2} y2={height}/>
                <line x1={x2 / 2} y1={height - 1} x2={x2} y2={height - 1}/>
                {ticks.y.map((tick, index) => (
                    <g key={index} transform={`translate(0, ${ROW_HEIGHT + index * ROW_HEIGHT})`}>
                        <text dx={dx} dy=".33em">{tick}</text>
                        <line x1={x1} x2={x2}/>
                    </g>
                ))}
                <YCursor key="cursor" label={ticks.yLabel}/>
            </g>
            <rect fill={`rgba(250, 225, 50, 0.25)`} x={40} y={top} width={AXIS_WIDTH - 50} height={view}/>
        </svg>
    )
}