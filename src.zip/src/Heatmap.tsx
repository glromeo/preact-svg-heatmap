import {h} from 'preact'
import {useMemo, useState} from 'preact/hooks'
import {JSXInternal} from 'preact/src/jsx'
import {Data, Sample} from './types'
import {useDispatch} from './hooks'

import './Heatmap.css'
import {XAxis} from './XAxis'
import {useHeatmapLayout} from './hooks/heatmapLayout'
import {YAxis} from './YAxis'
import {COLUMN_WIDTH, ROW_HEIGHT} from './constants'
import {HeatmapGrid} from './HeatmapGrid'

export type HeatmapProps = {
    data: Data
    tickX: (x: number) => string
    tickY: (y: number) => string
}


type Buckets = Map<number, Map<number, Sample[]>>

export type HeatmapView = {
    x: number
    y: number
    scale: number
}

export const INITIAL_VIEW: HeatmapView = {x: 0, y: 0, scale: 1}

export function Heatmap({data, tickX, tickY}: HeatmapProps) {

    const dispatch = useDispatch()

    const [container, setContainer] = useState<HTMLDivElement>(null)
    const {
        width,
        height,
        columns,
        rows
    } = useHeatmapLayout(container)

    const [view, setView] = useState<HeatmapView>(INITIAL_VIEW)

    useMemo(() => {
        dispatch({type: 'SET_VIEW', payload: view})
    }, [view])

    const left = view.x
    const top = view.y
    const scale = view.scale

    const [buckets, range] = useMemo(() => {
        if (!view) {
            return null
        }

        const buckets: Buckets = new Map()
        const columnWidth = COLUMN_WIDTH / scale
        const rowHeight = ROW_HEIGHT / scale
        const minX = left - columnWidth
        const minY = top - rowHeight
        const maxX = left + width / scale + columnWidth
        const maxY = top + height / scale + rowHeight

        for (const sample of data) {
            let x = sample.x * width
            let y = sample.y * height
            if (x >= minX && x < maxX && y >= minY && y < maxY) {
                x -= x % columnWidth
                y -= y % rowHeight
                let slice = buckets.get(x)
                if (slice === undefined) {
                    slice = new Map()
                    slice.set(y, [sample])
                    buckets.set(x, slice)
                } else {
                    const bucket = slice.get(y)
                    if (bucket === undefined) {
                        slice.set(y, [sample])
                    } else {
                        slice.get(y).push(sample)
                    }
                }
            }
        }

        return [buckets, range]
    }, [data, view])

    return (
        <div className="heatmap" ref={setContainer}>
            <XAxis width={width} origin={left} scale={scale} tick={tickX}
                   onChange={(origin, scale) => {
                       setView({
                           x: origin ?? view.x,
                           y: view.y,
                           scale: scale ?? view.scale
                       })
                   }}/>
            <YAxis height={height} origin={top} scale={scale} tick={tickY}
                   onChange={(origin, scale) => {
                       setView({
                           x: view.x,
                           y: origin ?? view.y,
                           scale: scale ?? view.scale
                       })
                   }}/>
            <HeatmapGrid width={width}
                         height={height}
                         view={view}
                         onViewChange={setView}
                         tiles={useMemo(() => {
                             const tiles: JSXInternal.Element[] = []
                             for (let [x, slice] of buckets) {
                                 for (let [y, bucket] of slice) {
                                     const value = bucket ? bucket.reduce((total, {z}) => total + z, 0) / bucket.length : 0
                                     const hasBadge = value && bucket.length > 1
                                     tiles.push(
                                         <g key={x + ':' + y}>
                                             <rect fill={`hsl(200,80%,${Math.round(100 - 100 * value)}%)`}
                                                   x={x * scale}
                                                   y={y * scale}
                                                   width={COLUMN_WIDTH} height={ROW_HEIGHT}/>
                                             {bucket.map(({x, y, z}) => (
                                                 <circle cx={(x * width) * scale}
                                                         cy={(y * height) * scale} r={6}
                                                         fill={`hsl(100,80%,${Math.round(100 - 100 * z)}%)`}/>
                                             ))}
                                             {hasBadge && (
                                                 <g transform={`translate(${x * scale},${y * scale})`}>
                                                     <circle className="badge-background" cx={12} cy={12}
                                                             r={bucket.length > 99 ? 12 : 8}/>
                                                     <text className="badge-number" x={12} y={15}
                                                           text-anchor="middle">{bucket.length}</text>
                                                 </g>
                                             )}
                                         </g>
                                     )
                                 }
                             }
                             return tiles
                         }, [data, width, height, view])}/>
        </div>
    )
}


