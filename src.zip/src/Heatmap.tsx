import {h} from 'preact'
import {useCallback, useLayoutEffect, useMemo, useRef, useState} from 'preact/hooks'
import {JSXInternal} from 'preact/src/jsx'

import {RectBox} from './hooks/heatmapGrid'
import {Data, Sample} from './types'
import {useDispatch} from './hooks'

import './Heatmap.css'

type Range = {
    min: number,
    max: number,
    span: number
}

export type HeatmapProps = {
    preview?: boolean,
    data: Data
    ranges: {
        x: Range,
        y: Range
    }
}


type Buckets = Record<number, Record<number, Sample[]>>

function addBucketValue(buckets: Buckets, x: number, y: number, sample: Sample) {
    let hzb = buckets[x]
    if (hzb === undefined) {
        buckets[x] = {
            [y]: [sample]
        }
    } else {
        let vtb = hzb[y]
        if (vtb === undefined) {
            hzb[y] = [sample]
        } else {
            hzb[y].push(sample)
        }
    }
}

type HeatmapSelection = {
    x: number;
    y: number;
    width: number;
    height: number;
    clientX: number;
    clientY: number;
    clientWidth: number;
    clientHeight: number;
    editing: boolean;
}

export type HeatmapModel = {
    data: Sample[]
    width: number
    height: number
    columns: number
    rows: number
}

const DEFAULT_MODEL = {
    data: [],
    width: 0,
    height: 0,
    columns: 0,
    rows: 0
}

const COLUMN_WIDTH = 90
const ROW_HEIGHT = 30

const NO_TRANSFORM = ['scale(1)', 'scale(1)']

function useBuckets(model: HeatmapModel, view: RectBox) {
    return useMemo(() => {
        if (view) {
            const buckets: Buckets = {}
            const {x, y, width, height} = view
            const columnWidth = COLUMN_WIDTH * view.width / model.width
            const rowHeight = ROW_HEIGHT * view.height / model.height
            const minX = x
            const minY = y
            const maxX = x + width
            const maxY = y + height
            for (const sample of model.data) {
                const x = sample.x * model.width
                const y = sample.y * model.height
                if (x >= minX && x < maxX && y >= minY && y < maxY) {
                    addBucketValue(buckets, x - x % columnWidth, y - y % rowHeight, sample)
                }
            }
            return buckets
        } else {
            return null
        }
    }, [model, view])
}

function renderCells(model: HeatmapModel, buckets: Buckets, onTileClick: (column: number, row: number) => void) {
    if (!buckets) {
        return null
    }
    const {columns, rows} = model
    const overlay: JSXInternal.Element[] = []
    for (let column = 0; column < columns; column++) {
        const slice = buckets[column]
        const x = column * COLUMN_WIDTH
        if (slice) {
            for (let row = 0; row < rows; row++) {
                const bucket = slice[row]
                const y = row * ROW_HEIGHT
                if (bucket) {
                    const value = bucket.reduce((total, {z}) => total + z, 0) / bucket.length
                    overlay.push(
                        <div className="heatmap-cell" onClick={() => onTileClick(column, row)} style={{
                            backgroundColor: `hsl(200,80%,${Math.round(100 - 100 * value)}%)`,
                            left: x,
                            top: y,
                            width: COLUMN_WIDTH,
                            height: ROW_HEIGHT
                        }}>{bucket?.[0].name} ({bucket?.length})</div>
                    )
                } else {
                    overlay.push(
                        <div className="heatmap-cell" onClick={() => onTileClick(column, row)} style={{
                            backgroundColor: `hsl(200, 80%, 100%)`,
                            left: x,
                            top: y,
                            width: COLUMN_WIDTH,
                            height: ROW_HEIGHT
                        }}/>
                    )
                }
            }
        } else {
            for (let row = 0; row < rows; row++) {
                const y = row * ROW_HEIGHT
                overlay.push(
                    <div className="heatmap-cell" onClick={() => onTileClick(column, row)} style={{
                        backgroundColor: `hsl(200, 80%, 100%)`,
                        left: x,
                        top: y,
                        width: COLUMN_WIDTH,
                        height: ROW_HEIGHT
                    }}/>
                )
            }
        }
    }
    return overlay
}

const AXIS_WIDTH = 60
const AXIS_HEIGHT = 40
const COLLAPSED_BOX:RectBox = {x:0, y:0, width:0, height:0}

export function Heatmap({data, ranges: {x: rangeX, y: rangeY}}: HeatmapProps) {

    const dispatch = useDispatch()

    const [container, setContainer] = useState<HTMLDivElement>(null)
    const [heatmap, setHeatmap] = useState<HeatmapModel>(DEFAULT_MODEL)
    const [view, setView] = useState<RectBox>(COLLAPSED_BOX)
    const [zoom, setZoom] = useState<RectBox>(COLLAPSED_BOX)
    const [drag, setDrag] = useState<{ offsetX: number, offsetY: number }>(null)

    useLayoutEffect(() => {
        const createModel = (container: HTMLDivElement) => {
            let {width, height} = container.getBoundingClientRect()
            let columns = Math.floor((width - AXIS_WIDTH) / COLUMN_WIDTH)
            let rows = Math.floor((height - AXIS_HEIGHT) / ROW_HEIGHT)
            return {
                data,
                width: columns * COLUMN_WIDTH,
                height: rows * ROW_HEIGHT,
                columns,
                rows
            }
        }
        if (container) {
            const observer = new ResizeObserver(() => {
                const model = createModel(container)
                setHeatmap(model)
                setView({x: 0, y: 0, width: model.width, height: model.height})
            })
            observer.observe(container)
            const model = createModel(container)
            setHeatmap(model)
            setView({x: 0, y: 0, width: model.width, height: model.height})
            return () => {
                observer.disconnect()
            }
        }
    }, [container])


    const viewBuckets = useBuckets(heatmap, view)

    const onTileClick = useCallback((column: number, row: number) => {
        const columnWidth = COLUMN_WIDTH * view.width / heatmap.width
        const rowHeight = ROW_HEIGHT * view.height / heatmap.height
        setZoom({
            x: view.x + column * columnWidth,
            y: view.y + row * rowHeight,
            width: columnWidth,
            height: rowHeight
        })
    }, [heatmap, view])

    const animationFrame = useRef(null)

    const [pointer, setPointer] = useState<({ x: number, y: number })>(null)

    console.log(viewBuckets)

    return (
        <div className="heatmap" ref={setContainer}>
            <svg style={{left: AXIS_WIDTH}} width={heatmap.width} height={AXIS_HEIGHT}>
                <g className="axis" transform={`translate(${-view.x},0)`}>
                    {useMemo(() => {
                        const {columns, width} = heatmap
                        const xAxis: JSXInternal.Element[] = []
                        const y2 = AXIS_HEIGHT - 10
                        const y1 = 2 * y2 / 3
                        const dy = y1 - 2
                        xAxis.push(<line x1={0} y1={y2} x2={width} y2={y2}/>)
                        xAxis.push(<line x1={1} y1={y2 / 2} x2={1} y2={y2}/>)
                        for (let column = 1; column < columns; column++) {
                            const x = column * COLUMN_WIDTH
                            xAxis.push(
                                <g transform={`translate(${x},0)`}>
                                    <text dy={dy}>{
                                        Math.round(100 * (rangeX.min + rangeX.span * column / columns))
                                    }</text>
                                    <line y1={y1} y2={y2}/>
                                </g>
                            )
                        }
                        xAxis.push(<line x1={width - 1} y1={y2 / 2} x2={width - 1} y2={y2}/>)
                        return xAxis
                    }, [heatmap])}
                </g>
                <g transform={`translate(${-view.x},0)`}>
                    {useMemo(() => {
                        if (pointer) {
                            const y2 = AXIS_HEIGHT - 10
                            const y1 = 2 * y2 / 3
                            return (
                                <g className="axis pointer" transform={`translate(${pointer.x},0)`}>
                                    <text dy={y1 - 2}>{
                                        (100 * (rangeX.min + rangeX.span * pointer.x / heatmap.width)).toFixed(2)
                                    }</text>
                                    <line y1={y1} y2={y2}/>
                                </g>
                            )
                        }
                    }, [heatmap, pointer])}
                </g>
                <rect fill={`rgba(250,150,50,0.25)`} x={view.x} y={view.y} width={view.width} height={view.height}/>
            </svg>
            <svg style={{top: AXIS_HEIGHT}} width={AXIS_WIDTH} height={heatmap.height}>
                <g className="axis" transform={`translate(0,${-view.y})`}>
                    {useMemo(() => {
                        const {rows, height} = heatmap
                        const yAxis: JSXInternal.Element[] = []
                        const x2 = AXIS_WIDTH - 10
                        const x1 = 3 * x2 / 4
                        const dx = x1 - 10
                        yAxis.push(<line x1={x2} y1={0} x2={x2} y2={height}/>)
                        yAxis.push(<line x1={x2 / 2} y1={1} x2={x2} y2={1}/>)
                        for (let row = 1; row < rows; row++) {
                            const y = row * ROW_HEIGHT
                            yAxis.push(
                                <g transform={`translate(0, ${y})`}>
                                    <text dx={dx} dy=".33em">{
                                        Math.round(100 * (rangeY.min + rangeY.span * row / rows))
                                    }</text>
                                    <line x1={x1} x2={x2}/>
                                </g>
                            )
                        }
                        yAxis.push(<line x1={x2 / 2} y1={height - 1} x2={x2} y2={height - 1}/>)
                        return yAxis
                    }, [heatmap])}
                </g>
                <g transform={`translate(0,${-view.y})`}>
                    {useMemo(() => {
                        if (pointer) {
                            const x2 = AXIS_WIDTH - 10
                            const x1 = 3 * x2 / 4
                            return (
                                <g className="axis pointer" transform={`translate(0, ${pointer.y})`}>
                                    <text dx={x1 - 16} dy=".33em">{
                                        (100 * (rangeY.min + rangeY.span * pointer.y / heatmap.height)).toFixed(2)
                                    }</text>
                                    <line x1={x1} x2={x2}/>
                                </g>
                            )
                        }
                    }, [heatmap, pointer])}
                </g>
            </svg>
            <svg className="heatmap-grid" style={{left: AXIS_WIDTH, top: AXIS_HEIGHT}}
                 width={heatmap.width}
                 height={heatmap.height}
                 onDblClick={useCallback(() => {
                     setView({x: 0, y: 0, width: heatmap.width, height: heatmap.height})
                 }, [heatmap])}
                 onMouseDown={useCallback(({offsetX, offsetY}) => {
                     setDrag({offsetX, offsetY})
                     setPointer(null)
                 }, [setDrag])}
                 onMouseMove={useCallback(event => {
                     cancelAnimationFrame(animationFrame.current)
                     animationFrame.current = requestAnimationFrame(() => {
                         const {offsetX, offsetY} = event
                         const x = offsetX + view.x
                         const y = offsetY + view.y
                         if (drag) {
                             let x = Math.min(Math.max(drag.offsetX - offsetX, -100), 100 + heatmap.width - view.width)
                             let y = Math.min(Math.max(drag.offsetY - offsetY, -100), 100 + heatmap.height - view.height)
                             setView({...view, x, y})
                         } else {
                             //setPointer({x, y})
                         }
                         dispatch({type: 'SET_POINTER', payload: {x, y, z: '?'}})
                     })
                     event.preventDefault()
                     event.stopPropagation()
                 }, [drag, view, heatmap])}
                 onMouseUp={useCallback(event => {
                     const {offsetX, offsetY} = event
                     const x = offsetX + view.x
                     const y = offsetY + view.y
                     setPointer({x, y})
                     setDrag(null)
                 }, [])}
                 onMouseLeave={useCallback(() => {
                     setPointer(null)
                     setDrag(null)
                 }, [])}
                 onWheel={useCallback(({deltaY, offsetX, offsetY}) => {
                     let x = offsetX + view.x
                     let y = offsetY + view.y
                     let width, height
                     if (view) {
                         if (deltaY < 0) {
                             width = view.width / 1.25
                             height = view.height / 1.25
                         } else {
                             width = view.width * 1.25
                             height = view.height * 1.25
                         }
                         x -= (2 * view.x + view.x + view.width)
                         y -= (2 * view.y + view.y + view.height)
                     } else {
                         if (deltaY < 0) {
                             width = heatmap.width / 1.25
                             height = heatmap.height / 1.25
                         } else {
                             width = heatmap.width
                             height = heatmap.height
                         }
                         x -= (2 * view.x + view.x + view.width)
                         y -= (2 * view.y + view.y + view.height)
                     }
                     setView({x: 0, y: 0, width, height})
                 }, [heatmap, view])}>
                <g className="grid" transform={`translate(${-view.x},${-view.y})`}>
                    {useMemo(() => {
                        const columnWidth = COLUMN_WIDTH * view.width / heatmap.width
                        const rowHeight = ROW_HEIGHT * view.height / heatmap.height
                        const grid: JSXInternal.Element[] = []
                        for (let [key, slice] of Object.entries(viewBuckets)) {
                            const x = Number(key)
                            for (let [key, bucket] of Object.entries(slice)) {
                                const value = bucket ? bucket.reduce((total, {z}) => total + z, 0) / bucket.length : 0
                                const y = Number(key)
                                const hasBadge = value && bucket.length > 1
                                grid.push(
                                    <g key={`${y}x${x}`} data-key={`${y}x${x}`}
                                       transform={`translate(${x},${y})`}>
                                        <rect fill={`hsl(200,80%,${Math.round(100 - 100 * value)}%)`} x={0} y={0}
                                              width={columnWidth} height={rowHeight}/>
                                        <path
                                            d={`M ${0} ${0} L ${0} ${rowHeight} M ${0} ${0} L ${columnWidth} ${0}`}/>
                                        {hasBadge && (
                                            <g>
                                                <circle className="badge-background" cx={0} cy={0}
                                                        r={bucket.length > 99 ? 12 : 8}/>
                                                <text className="badge-number" x={0} y={3}
                                                      text-anchor="middle">{bucket.length}</text>
                                            </g>
                                        )}
                                    </g>
                                )
                            }
                        }
                        return grid
                    }, [heatmap, view, viewBuckets])}
                </g>
            </svg>
        </div>
    )
}
