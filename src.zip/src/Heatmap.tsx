import {h} from 'preact'
import {useCallback, useMemo, useRef, useState} from 'preact/hooks'
import {JSXInternal} from 'preact/src/jsx'
import {Data, Sample} from './types'
import {useDispatch} from './hooks'

import './Heatmap.css'
import {AXIS_HEIGHT, AXIS_WIDTH, Ticks, XAxis, YAxis} from './HeatmapAxes'
import {useHeatmapLayout} from './hooks/heatmapLayout'

export type HeatmapProps = {
    preview?: boolean,
    data: Data
}


type Buckets = Map<number, Map<number, Sample[]>>

export const COLUMN_WIDTH = 96
export const ROW_HEIGHT = 32

type HeatmapView = {
    x: number
    y: number
    scale: number
}

const INITIAL_VIEW: HeatmapView = {x: 0, y: 0, scale: 1}

export function Heatmap({data}: HeatmapProps) {

    const dispatch = useDispatch()

    const [container, setContainer] = useState<HTMLDivElement>(null)
    const {
        width,
        height,
        columns,
        rows
    } = useHeatmapLayout(container)

    const [view, setView] = useState<HeatmapView>(INITIAL_VIEW)

    useMemo(() => {
        dispatch({type: 'SET_VIEW', payload: view})
    }, [view])

    const left = view.x
    const top = view.y
    const scale = view.scale

    const ticks = useMemo<Ticks>(() => {
        const scaleX = 1 / (scale * columns)
        const baseX = left / width
        const x: string[] = []
        for (let column = 1; column < columns; column++) {
            x.push((baseX + scaleX * column).toFixed(2))
        }
        const scaleY = 1 / (scale * rows)
        const baseY = top / height
        const y: string[] = []
        for (let row = 1; row < rows; row++) {
            y.push((baseY + scaleY * row).toFixed(2))
        }
        return {
            x,
            y,
            xLabel: (x: number) => ((left + x / scale) / width).toFixed(2),
            yLabel: (y: number) => ((top + y / scale) / height).toFixed(2)
        }
    }, [columns, rows, width, height, view])

    const cappedScale = Math.max(1, scale)

    return (
        <div className="heatmap" ref={setContainer}>
            <XAxis width={width} left={left} scale={cappedScale} ticks={ticks}/>
            <YAxis height={height} top={top} scale={cappedScale} ticks={ticks}/>
            <HeatmapGrid width={width}
                         height={height}
                         view={view}
                         onViewChange={setView}
                         tiles={useMemo(() => {
                             if (!view) {
                                 return null
                             }

                             const buckets: Buckets = new Map()
                             const columnWidth = COLUMN_WIDTH / scale
                             const rowHeight = ROW_HEIGHT / scale
                             const minX = left - columnWidth
                             const minY = top - rowHeight
                             const maxX = left + width / scale + columnWidth
                             const maxY = top + height / scale + rowHeight

                             for (const sample of data) {
                                 let x = sample.x * width
                                 let y = sample.y * height
                                 if (x >= minX && x < maxX && y >= minY && y < maxY) {
                                     x -= x % columnWidth
                                     y -= y % rowHeight
                                     let slice = buckets.get(x)
                                     if (slice === undefined) {
                                         slice = new Map()
                                         slice.set(y, [sample])
                                         buckets.set(x, slice)
                                     } else {
                                         const bucket = slice.get(y)
                                         if (bucket === undefined) {
                                             slice.set(y, [sample])
                                         } else {
                                             slice.get(y).push(sample)
                                         }
                                     }
                                 }
                             }

                             const tiles: JSXInternal.Element[] = []
                             for (let [x, slice] of buckets) {
                                 for (let [y, bucket] of slice) {
                                     const value = bucket ? bucket.reduce((total, {z}) => total + z, 0) / bucket.length : 0
                                     const hasBadge = value && bucket.length > 1
                                     tiles.push(
                                         <g key={x + ':' + y}>
                                             <rect fill={`hsl(200,80%,${Math.round(100 - 100 * value)}%)`}
                                                   x={x * scale}
                                                   y={y * scale}
                                                   width={COLUMN_WIDTH} height={ROW_HEIGHT}/>
                                             {bucket.map(({x, y, z}) => (
                                                 <circle cx={(x * width) * scale}
                                                         cy={(y * height) * scale} r={6}
                                                         fill={`hsl(100,80%,${Math.round(100 - 100 * z)}%)`}/>
                                             ))}
                                             {hasBadge && (
                                                 <g transform={`translate(${x * scale},${y * scale})`}>
                                                     <circle className="badge-background" cx={12} cy={12}
                                                             r={bucket.length > 99 ? 12 : 8}/>
                                                     <text className="badge-number" x={12} y={15}
                                                           text-anchor="middle">{bucket.length}</text>
                                                 </g>
                                             )}
                                         </g>
                                     )
                                 }
                             }
                             return tiles
                         }, [data, width, height, view])}/>
        </div>
    )
}

export type HeatmapGridProps = {
    width: number
    height: number
    view: HeatmapView
    tiles: JSXInternal.Element[]
    onViewChange: (view: HeatmapView) => void
}

const gridStyle = {left: AXIS_WIDTH, top: AXIS_HEIGHT}

function HeatmapGrid({width, height, view, tiles, onViewChange}: HeatmapGridProps): JSXInternal.Element {
    const dispatch = useDispatch()
    const animationFrame = useRef(0)
    const gRef = useRef<SVGGElement>()
    const [drag, setDrag] = useState<{ x: number, y: number, offsetX: number, offsetY: number }>(null)
    const [transition, setTransition] = useState<string>(null)

    const left = view.x
    const top = view.y
    const scale = view.scale

    const transform = `translate(${-left * scale},${-top * scale})` // scale(${1/zx},${1/zy})`

    return (
        <svg className="heatmap-grid" style={gridStyle}
             width={width}
             height={height}
             onDblClick={event => {
                 const target = event.target as SVGRectElement
                 let x = target.x.baseVal.value
                 let y = target.y.baseVal.value
                 let scale = Math.min(width/COLUMN_WIDTH, height/ROW_HEIGHT)
                 const hvw = width / scale
                 const hvh = height / scale
                 x = Math.max(0, Math.min(width - hvw, x))
                 y = Math.max(0, Math.min(height - hvh, y))
                 onViewChange({x, y, scale})
             }}
             onMouseDown={event => {
                 const g = gRef.current!
                 const svg = g.parentElement as unknown as SVGSVGElement
                 g.transform.baseVal.appendItem(svg.createSVGTransform())
                 setDrag({
                         offsetX: event.offsetX,
                         offsetY: event.offsetY,
                         x: left,
                         y: top
                     }
                 )
             }}
             onMouseMove={event => {
                 const g = gRef.current!
                 cancelAnimationFrame(animationFrame.current)
                 animationFrame.current = requestAnimationFrame(() => {
                     let {offsetX, offsetY} = event
                     if (drag) {
                         const svg = g.parentElement as unknown as SVGSVGElement
                         let dx = event.offsetX - drag.offsetX
                         let dy = event.offsetY - drag.offsetY
                         g.transform.baseVal.getItem(1).setTranslate(dx, dy)
                     }
                     const {x, y} = {
                         x: left + offsetX / scale,
                         y: top + offsetY / scale
                     }
                     dispatch({type: 'SET_POINTER', payload: {x, y, z: '-'}})
                 })
                 event.preventDefault()
                 event.stopPropagation()
             }}
             onMouseUp={event => {
                 if (drag) {
                     gRef.current!.transform.baseVal.removeItem(1)
                     let dx = (event.offsetX - drag.offsetX) / scale
                     let dy = (event.offsetY - drag.offsetY) / scale
                     let x = Math.max(0, Math.min(width - width / scale, drag.x - dx))
                     let y = Math.max(0, Math.min(height - height / scale, drag.y - dy))
                     onViewChange({x, y, scale})
                     setDrag(null)
                 }
             }}
             onMouseLeave={useCallback(() => {
                 setDrag(null)
             }, [])}
             onWheel={event => {
                 let {offsetX: x, offsetY: y} = event
                 let scale: number
                 if (event.deltaY < 0) {
                     scale = view.scale * 1.1
                     x = left + (1.1 * x - width / 2) / scale
                     y = top + (1.1 * y - height / 2) / scale
                 } else {
                     scale = view.scale / 1.1
                     x = left - width / view.scale * 0.125
                     y = top - height / view.scale * 0.125
                 }
                 const hvw = width / scale
                 const hvh = height / scale
                 x = Math.max(0, Math.min(width - hvw, x))
                 y = Math.max(0, Math.min(height - hvh, y))
                 onViewChange({x, y, scale})
             }}>
            <g className="grid animated" ref={gRef}
               onTransitionEnd={event => {
                   console.log('transition end')
               }}
               transform={transform}>
                <g>{tiles}</g>
                <g>{useMemo(() => {
                    const lines: JSXInternal.Element[] = []
                    const columnWidth = COLUMN_WIDTH
                    const rowHeight = ROW_HEIGHT
                    let x1 = Math.max(0, left)
                    let y1 = Math.max(0, top)
                    const minX = x1 - (x1 % columnWidth)
                    const minY = y1 - (y1 % rowHeight)
                    const maxScale = Math.max(1, scale)
                    const maxX = width * maxScale
                    const maxY = height * maxScale
                    for (let x = minX; x <= maxX; x += columnWidth) {
                        lines.push(<line key={`meridian-${x}`} x1={x} y1={minY} x2={x} y2={maxY}/>)
                    }
                    for (let y = minY; y <= maxY; y += rowHeight) {
                        lines.push(<line key={`parallel-${y}`} x1={minX} y1={y} x2={maxX} y2={y}/>)
                    }
                    return lines
                }, [width, height, view])}</g>
            </g>
        </svg>
    )
}