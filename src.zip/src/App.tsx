import {createContext, h, VNode} from 'preact'
import {useMemo} from 'preact/hooks'
import {Heatmap} from './Heatmap'
import './App.css'
import {AppState} from './types'
import {createStore, useData, useSelector} from './hooks'

interface Props {
    color?: string;
}

const store = createStore({
    pointer: {
        x: 0,
        y: 0,
        z: 1
    },
    view: {
        x:0,
        y:0,
        scale:1.5
    }
}, (state, action) => {
    switch (action.type) {
        case "SET_POINTER":
            return {
                pointer: action.payload
            }
        case "SET_VIEW":
            return {
                view: action.payload
            }
    }
    return state
})

Object.defineProperty(window, "store", {enumerable:true, value: store})
Object.defineProperty(window, "dispatch", {enumerable:true, value: store.dispatch.bind(store)})

export const AppContext = createContext(store)

function Header() {
    const pointer = useSelector<AppState, AppState['pointer']>(state => state.pointer)
    const view = useSelector<AppState, AppState['view']>(state => state.view)
    return <div className="Header">
        <div>
            <span>x:</span>
            <span>{Number(pointer.x).toFixed(3)}</span>
        </div>
        <div>
            <span>y:</span>
            <span>{Number(pointer.y).toFixed(3)}</span>
        </div>
        <div>
            <span>z:</span>
            <span>{Number(pointer.z).toFixed(3)}</span>
        </div>
        <div>
            <span>ox:</span>
            <span>{Number(view.x).toFixed(3)}</span>
        </div>
        <div>
            <span>oy:</span>
            <span>{Number(view.y).toFixed(3)}</span>
        </div>
        <div>
            <span>scale:</span>
            <span>{Number(view.scale).toFixed(3)}</span>
        </div>
    </div>
}

export default function App(props: Props): VNode {

    const data = useData()

    return (
        <AppContext.Provider value={store}>
            <div className="App">
                <Header />
                <div className="Body">
                    <Heatmap data={data} tickX={x => x.toFixed(2)} tickY={y => y.toFixed(2)}/>
                </div>
            </div>
        </AppContext.Provider>
    )
}
