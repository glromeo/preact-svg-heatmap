import {useSelector} from './hooks'
import {AppState} from './types'
import {AXIS_HEIGHT} from './constants'
import {h} from 'preact'

export function XCursor({width, origin, label}: { width: number, origin: number, label: (x: number) => string }) {
    const pointerX = useSelector<AppState, number>(state => state.pointer.x)
    const x = Math.min(width, Math.max(0, pointerX - origin))
    const y2 = AXIS_HEIGHT - 10
    const y1 = 2 * y2 / 3
    return (
        <g className="axis pointer" transform={`translate(${x},0)`}>
            <text dy={y1 - 2}>{label(x / width)}</text>
            <line y1={y1} y2={y2}/>
        </g>
    )
}