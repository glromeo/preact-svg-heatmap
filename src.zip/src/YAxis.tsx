import {h} from 'preact'
import {useDispatch} from './hooks'
import {useRef, useState} from 'preact/hooks'
import {AXIS_HEIGHT, AXIS_WIDTH, ROW_HEIGHT} from './constants'
import {YCursor} from './YCursor'

const trxBaseVal = (svg: SVGSVGElement) => (svg.firstElementChild as SVGGElement).transform.baseVal

export function YAxis(props: { height: number, origin: number, scale: number, tick: (y: number) => string, onChange: (origin: number | undefined, scale: number | undefined) => void }) {
    const {height, origin, scale, tick, onChange} = props
    const dispatch = useDispatch()

    const x2 = AXIS_WIDTH - 10
    const x1 = 3 * x2 / 4
    const dx = x1 - 10

    const rowHeight = ROW_HEIGHT / Math.floor(scale)
    let minY = Math.max(0, Math.min(height - height / scale, -origin))
    minY -= minY % rowHeight
    const maxY = height

    const ticks = []
    for (let y = minY; y < maxY; y += rowHeight) {
        ticks.push(
            <g key={y} transform={`translate(0, ${y})`}>
                <text className="y-tick" dx={dx} dy=".33em">{tick(y / height)}</text>
                <line x1={x1} x2={x2}/>
            </g>
        )
    }

    const [svg, setSvg] = useState<SVGSVGElement>(null)

    const animationFrame = useRef(0)
    const [mouseDownY, setMouseDownY] = useState<number>(null)

    const shrink = 1 / scale

    const toPoint = (offsetY: number) => origin + offsetY / scale

    return (
        <svg ref={setSvg} style={{top: AXIS_HEIGHT}} height={height} width={AXIS_WIDTH}
             onMouseDown={event => {
                 trxBaseVal(svg).appendItem(svg.createSVGTransform())
                 setMouseDownY(toPoint(event.offsetY))
             }}
             onMouseMove={event => {
                 cancelAnimationFrame(animationFrame.current)
                 animationFrame.current = requestAnimationFrame(() => {
                     let y = toPoint(event.offsetY)
                     if (mouseDownY) {
                         let dy = y - mouseDownY
                         y -= dy
                         trxBaseVal(svg).getItem(2).setTranslate(0, dy)
                     }
                     dispatch({
                         type: 'SET_POINTER',
                         payload: {
                             x: 0,
                             y: y - origin,
                             z: '-'
                         }
                     })
                 })
             }}
             onMouseUp={event => {
                 if (mouseDownY) {
                     trxBaseVal(svg).removeItem(2)
                     const dy = toPoint(event.offsetY) - mouseDownY
                     onChange(origin + dy * scale, undefined)
                     setMouseDownY(null)
                 }
             }}
             onWheel={event => {
                 let update: number
                 if (event.deltaY < 0) {
                     update = scale * 1.125
                 } else {
                     update = Math.max(1, scale / 1.125)
                 }
                 let offsetY = event.offsetY * scale / update
                 offsetY -= offsetY % rowHeight + rowHeight / 2
                 let y = toPoint(offsetY)
                 onChange(origin * update / scale + (y - y * update / scale), update)
             }}>
            <g className="axis" transform={`scale(1, ${scale}) translate(0,${origin})`}>
                <line key="top" x1={x2 / 2} y1={shrink} x2={x2} y2={shrink}/>
                <line key="right" x1={x2} y1={0} x2={x2} y2={height}/>
                <line key="bottom" x1={x2 / 2} y1={height - shrink} x2={x2} y2={height - shrink}/>
                {ticks}
                <YCursor key="cursor" height={height} origin={origin} label={tick}/>
            </g>
            {/*<rect fill={`rgba(250, 225, 50, 0.25)`} x={40} y={top} width={AXIS_WIDTH - 50} height={view}/>*/}
            <style>{`
                line { vector-effect: non-scaling-stroke; }
                .y-tick { transform: scale(1,${shrink}); }
            `}</style>
        </svg>
    )
}
