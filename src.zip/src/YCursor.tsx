import {useSelector} from './hooks'
import {AppState} from './types'
import {AXIS_WIDTH} from './constants'
import {h} from 'preact'

export function YCursor({height, origin, label}: { height: number, origin: number, label: (y: number) => string }) {
    const pointerY = useSelector<AppState, number>(state => state.pointer.y)
    const y = Math.min(height, Math.max(0, pointerY - origin))
    const x2 = AXIS_WIDTH - 10
    const x1 = 3 * x2 / 4
    return (
        <g className="axis pointer" transform={`translate(0,${y})`}>
            <text dx={x1 - 16} dy=".33em">{label(y / height)}</text>
            <line x1={x1} x2={x2}/>
        </g>
    )
}